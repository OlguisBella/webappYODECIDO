module.exports={

    PORT: process.env.PORT || 3000,
   //DB: 'mongodb://localhost:27017/clientes'
    DB: 'mongodb://admin:2019@68.66.207.7:27017/proyecto'

}