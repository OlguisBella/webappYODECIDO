# MEAN CRUD with Angular 6

# Tools
- ![Rest Client for VSCODE](https://marketplace.visualstudio.com/items?itemName=humao.rest-client)