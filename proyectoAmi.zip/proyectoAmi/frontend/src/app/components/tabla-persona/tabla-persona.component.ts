import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabla-persona',
  templateUrl: './tabla-persona.component.html',
  styleUrls: ['./tabla-persona.component.css']
})
export class TablaPersonaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
